# Cuestionario

## Cuestionario HTML
![](cuestionariohtml.png)
![](cuestionariohtml2.png)
![](cuestionariohtml3.png)
![](cuestionariohtml4.png)
es esto?
![](cuestionariohtml5.png)
## Index HTML
![](indexhtml.png)
## Variables CSS
![](variablecss.png)
## Index CSS
![](indexcss0.png)
![](indexcss5.png)
![](indexcss6.png)
## Cuestionario CSS
![](indexcss2.png)
![](indexcss.png)
![](indexcss3.png)
![](indexcss4.png)
![](cuestionariocss2.png)
![](cuestionariocss3.png)
animaciones
![](cuestionariocss.png)

box imagenes
![](cuestionariocss4.png)
![](cuestionariocss5.png)

## CuestionarioJS
![](cuestinariojs.png)
Encima de la siguiente
``` js
let cuestionario = []
```
![](cuestinariojs3.png)
![](cuestionariojs4.png)

corrige preguntas

![](cuestionariojs5.png)
![](cuestionariojs6.png)
![](cuestionariojs7.png)
![](cuestionariojs8.png)
![](cuestionariojs9.png)
![](cuestionariojs10.png)
![](cuestionariojs11.png)
![](cuestionariojs12.png)
![](cuestionariojs14.jpg)
![](cuestionariojs15.png)

panel ayuda
![](cuestionariojs16.png)
![](cuestinariojs16.png)

![](cuestionariojs17.png)
## ImagenesJS
![](imagenesjs.png)
## CuestionarioJS 2
![](origendesconocido2.png)
![](cuestionariojs2.png)
![](origendesconocido.png)
![](cuestionariojs2-2.png)

